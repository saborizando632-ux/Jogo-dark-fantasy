# Cinzas de Valmora — projeto Unity (Android)

Unity 2022.3 LTS · URP · Input System · glTFast · C#. O Three.js foi abandonado.

## Status (leia primeiro)
**Este código foi escrito sem Unity disponível: não foi compilado nem executado.** Espere corrigir alguns
erros de compilação na primeira abertura. Nada foi testado em celular. Os pontos mais incertos:
versões dos pacotes (`Packages/manifest.json`), criação do URP por script, e detecção de mouse no Android.

## Como abrir
1. Unity Hub -> Add project -> esta pasta. Versão 2022.3.21f1 (ou outra 2022.3 LTS; ajuste `ProjectVersion.txt`).
2. Aguarde os pacotes e a importação dos `.glb` (glTFast). Se o Unity pedir, reinicie (ativa o Input System novo).
3. Menu **Valmora > 1 - Preparar projeto**. Isso gera: URP, material de cor por vértice, prefabs dos GLB com pivôs
   nas articulações, clipes e Animator, céu com 2 luas e estrelas, terreno, castelo, inimigos, chefe, pós-processamento
   e `Assets/Scenes/Main.unity`, além das configurações Android (IL2CPP, ARM64, API 24+, paisagem).
4. Abra `Main.unity`, aperte Play. **Commite** os arquivos gerados.

## Compilar
- Local: **Valmora > 3 - Build APK** / **4 - Build AAB** (saída em `Builds/Android/`).
- GitHub Actions: `.github/workflows/android.yml` (GameCI). Secrets: `UNITY_LICENSE`, `UNITY_EMAIL`, `UNITY_PASSWORD`
  (ver game.ci/docs/github/activation). Gera APK e AAB como artefatos. Assinatura de release opcional:
  `ANDROID_KEYSTORE_PATH`, `ANDROID_KEYSTORE_PASS`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASS`.

## Controles (Input System)
- Toque: analógico esquerdo (mover), direito (câmera), Golpear, Pular, Rolar, Guarda, Correr, Usar, Bolsa, Pausa.
  `OnScreenStick`/`OnScreenButton` escrevem num Gamepad virtual. Tamanho e posição são editáveis em Configurações.
- Teclado e mouse: WASD, Espaço, Shift, Ctrl, E, I, Q (frasco), Esc, mouse esq. ataca / dir. bloqueia, mouse move a câmera.
  Teclas remapeáveis em Configurações. Ao detectar teclado/mouse os controles virtuais somem; um toque na tela
  ou a remoção dos dispositivos os traz de volta, sem reiniciar a partida.

## O que usa os assets enviados
`ancient_guardian` (jogador, sentinelas, chefe), `root_brute` (brutos e gigantes), `dead_tree` (170 árvores),
`ruined_arch` (arcos/ruínas/portão), `ancient_chest` (baús), `iron_sword` (drop do chefe).
`stone_albedo` (muralhas), `dead_wood_albedo` e `worn_iron_albedo` (portão), `ash_ground_albedo` (terreno).

## Limitações conhecidas (honestas)
- Os GLB não têm UVs, rig nem animações. As cores vêm dos vértices (material `Particles/Lit` do URP). As
  animações são clipes reais do Unity Animator girando pivôs criados nas articulações; são simples, não "realistas".
- Jogador e chefe usam o mesmo modelo (guardião) em escalas diferentes.
- Se os modelos aparecerem de costas, gire o filho `Model` em 180° ou ajuste no gerador.
- URP não tem neblina volumétrica nativa: usa-se neblina exponencial animada + partículas. Sem reflexo planar na água.
- Não implementado: cidades abandonadas, cavernas/eco, outras regiões, outros chefes, streaming de regiões e LOD
  (só distância de desenho por qualidade). Faltou também a parte final do seu prompt (cortado em "LOD para…").
- Áudio é sintetizado por código (sem música real).
