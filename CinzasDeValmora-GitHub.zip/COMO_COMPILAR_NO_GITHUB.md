# Compilar no GitHub (passo a passo)

1. Crie um repositório novo no GitHub (pode ser privado).
2. Envie TODO o conteúdo desta pasta para a raiz do repositório (Assets/, Packages/, ProjectSettings/, .github/ ficam na raiz).
3. Licença da Unity (obrigatória, uma vez só). No repositório: Settings > Secrets and variables > Actions > New repository secret.
   Crie estes 3 secrets:
   - UNITY_EMAIL: e-mail da sua conta Unity
   - UNITY_PASSWORD: senha da conta Unity
   - UNITY_LICENSE: conteúdo do arquivo .ulf de licença
   Como obter o .ulf (licença Personal gratuita): siga https://game.ci/docs/github/activation
   (rode o workflow "Acquire activation file", ative em license.unity3d.com e cole o .ulf no secret).
4. Aba Actions > "Build Android (APK + AAB)" > Run workflow (ou faça um push na branch main).
5. Quando terminar, abra a execução e baixe os artefatos no fim da página:
   - CinzasDeValmora-androidPackage (APK, instala direto no celular)
   - CinzasDeValmora-androidAppBundle (AAB, para a Play Store)

Se o build falhar, abra o log do passo que ficou vermelho e me envie as linhas com "error".
