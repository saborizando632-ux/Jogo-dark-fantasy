using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Valmora
{
    public class SettingsManager : MonoBehaviour
    {
        public static SettingsManager I;
        public static readonly string[] QNames = { "Muito baixo", "Baixo", "Médio", "Alto", "Ultra" };
        public int Quality = 3; public float Sens = 1f, TouchScale = 1f;

        static readonly float[] RS = { .5f, .65f, .8f, 1f, 1f };       // escala de renderização
        static readonly int[] MS = { 1, 1, 2, 4, 4 };                   // MSAA
        static readonly float[] SD = { 0f, 25f, 45f, 70f, 110f };       // distância de sombras
        static readonly float[] FD = { .035f, .028f, .024f, .02f, .016f };
        static readonly float[] FAR = { 140, 200, 280, 380, 500 };      // distância de desenho

        void Awake()
        {
            I = this;
            Quality = PlayerPrefs.GetInt("q", 3);
            Sens = PlayerPrefs.GetFloat("sens", 1f);
            TouchScale = PlayerPrefs.GetFloat("ts", 1f);
            Apply();
        }

        public void Save()
        {
            PlayerPrefs.SetInt("q", Quality); PlayerPrefs.SetFloat("sens", Sens); PlayerPrefs.SetFloat("ts", TouchScale);
            PlayerPrefs.Save();
        }

        public void Apply()
        {
            Quality = Mathf.Clamp(Quality, 0, 4);
            var urp = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;
            if (urp != null)
            {
                urp.renderScale = RS[Quality];
                urp.msaaSampleCount = MS[Quality];
                urp.shadowDistance = Mathf.Max(1f, SD[Quality]);
            }
            var sun = RenderSettings.sun;
            if (sun) sun.shadows = Quality == 0 ? LightShadows.None : LightShadows.Soft;
            if (Camera.main) Camera.main.farClipPlane = FAR[Quality];
        }

        void Update()   // neblina dinâmica
        {
            RenderSettings.fogDensity = FD[Mathf.Clamp(Quality, 0, 4)] * (1f + 0.3f * Mathf.Sin(Time.time * 0.15f));
        }
    }

    /// <summary>Todo o áudio é sintetizado em código (sem arquivos): vento, drone, música de batalha e efeitos.</summary>
    public class ProceduralAudio : MonoBehaviour
    {
        public static ProceduralAudio I;
        readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        AudioSource battle;
        const int SR = 44100;

        static float R() { return UnityEngine.Random.value * 2f - 1f; }
        static float TAU => Mathf.PI * 2f;

        AudioClip Make(string n, float len, Func<float, float> f)
        {
            int N = (int)(SR * len); var d = new float[N];
            for (int i = 0; i < N; i++) d[i] = Mathf.Clamp(f(i / (float)SR), -1f, 1f);
            var c = AudioClip.Create(n, N, 1, SR, false); c.SetData(d, 0); return c;
        }

        AudioSource Loop(string n, float vol)
        {
            var s = gameObject.AddComponent<AudioSource>();
            s.clip = clips[n]; s.loop = true; s.volume = vol; s.spatialBlend = 0; s.Play(); return s;
        }

        void Awake()
        {
            I = this;
            float lp = 0;
            clips["wind"] = Make("wind", 4f, t => { lp += (R() - lp) * 0.02f; return lp * 3.2f * (0.15f + 0.85f * Mathf.Sin(Mathf.PI * t / 4f)); });
            clips["drone"] = Make("drone", 8f, t => (Mathf.Sin(TAU * 55f * t) + 0.6f * Mathf.Sin(TAU * 82.5f * t) + 0.4f * Mathf.Sin(TAU * 110f * t)) * 0.25f);
            clips["battle"] = Make("battle", 4f, t => Mathf.Sign(Mathf.Sin(TAU * 73.5f * t)) * (0.5f + 0.5f * Mathf.Sin(TAU * 2f * t)) * 0.3f);
            clips["hit"] = Make("hit", .2f, t => R() * Mathf.Exp(-t * 20f) * .7f + Mathf.Sin(TAU * 140f * t) * Mathf.Exp(-t * 12f) * .5f);
            clips["swing"] = Make("swing", .25f, t => R() * Mathf.Sin(Mathf.PI * t / .25f) * .25f);
            clips["step"] = Make("step", .1f, t => R() * Mathf.Exp(-t * 40f) * .35f);
            clips["stepStone"] = Make("stepStone", .1f, t => (R() * .3f + Mathf.Sin(TAU * 380f * t) * .3f) * Mathf.Exp(-t * 45f));
            clips["block"] = Make("block", .25f, t => Mathf.Sign(Mathf.Sin(TAU * 880f * t)) * Mathf.Exp(-t * 18f) * .3f);
            clips["roar"] = Make("roar", 1f, t => (Mathf.Repeat(t * 55f, 1f) * 2f - 1f) * Mathf.Sin(Mathf.PI * t) * .5f);
            clips["chest"] = Make("chest", .5f, t => Mathf.Sin(TAU * 520f * (1f + t) * t) * Mathf.Exp(-t * 6f) * .4f);
            clips["heal"] = Make("heal", .5f, t => Mathf.Sin(TAU * 600f * (1f + t * 2f) * t) * Mathf.Exp(-t * 5f) * .35f);

            Loop("wind", 0.55f); Loop("drone", 0.5f);
            battle = Loop("battle", 0f);
        }

        void Update()
        {
            if (battle) battle.volume = Mathf.MoveTowards(battle.volume, Game.BossActive ? 0.35f : 0f, Time.deltaTime * 0.5f);
        }

        public void Play(string n, Vector3 pos)
        {
            if (clips.TryGetValue(n, out var c)) AudioSource.PlayClipAtPoint(c, pos, 0.8f);
        }
    }
}
