using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.OnScreen;
using UnityEngine.UI;

namespace Valmora
{
    public class DragMove : MonoBehaviour, IDragHandler, IEndDragHandler
    {
        public string key; RectTransform rt; Canvas cv;
        void Awake() { rt = (RectTransform)transform; }
        public void OnDrag(PointerEventData e)
        {
            if (cv == null) cv = GetComponentInParent<Canvas>();
            rt.anchoredPosition += e.delta / cv.scaleFactor;
        }
        public void OnEndDrag(PointerEventData e)
        {
            PlayerPrefs.SetString("tc_" + key, rt.anchoredPosition.x.ToString(CultureInfo.InvariantCulture) + "," + rt.anchoredPosition.y.ToString(CultureInfo.InvariantCulture));
        }
    }

    /// <summary>Analógicos e botões medievais. Escrevem num Gamepad virtual (Input System).</summary>
    public class TouchControls : MonoBehaviour
    {
        GameObject root; Sprite ring, disc; Font font;
        readonly List<RectTransform> items = new List<RectTransform>();
        readonly List<Behaviour> onScreen = new List<Behaviour>();
        readonly List<DragMove> drags = new List<DragMove>();

        static readonly Color Gold = new Color(.72f, .57f, .23f);

        Sprite MakeSprite(bool filled)
        {
            const int n = 128; var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(n / 2f, n / 2f)) / (n / 2f);
                Color c = d > 1f ? Color.clear : d > 0.9f ? Gold : (filled ? new Color(.45f, .35f, .15f, .75f) : new Color(.07f, .06f, .09f, .55f));
                t.SetPixel(x, y, c);
            }
            t.Apply(); return Sprite.Create(t, new Rect(0, 0, n, n), new Vector2(.5f, .5f));
        }

        RectTransform Place(string name, Transform parent, Vector2 anchor, Vector2 pos, float size, Sprite sp, bool raycast)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            var rt = (RectTransform)go.transform; rt.SetParent(parent, false);
            rt.anchorMin = rt.anchorMax = anchor; rt.pivot = new Vector2(.5f, .5f);
            rt.sizeDelta = new Vector2(size, size);
            var im = go.GetComponent<Image>(); im.sprite = sp; im.raycastTarget = raycast;
            string saved = PlayerPrefs.GetString("tc_" + name, "");
            if (saved.Length > 0)
            {
                var p = saved.Split(',');
                pos = new Vector2(float.Parse(p[0], CultureInfo.InvariantCulture), float.Parse(p[1], CultureInfo.InvariantCulture));
            }
            rt.anchoredPosition = pos;
            return rt;
        }

        void AddDrag(RectTransform rt, string name)
        {
            var d = rt.gameObject.AddComponent<DragMove>(); d.key = name; d.enabled = false; drags.Add(d);
        }

        void Stick(string name, string path, Vector2 anchor, Vector2 pos, float size)
        {
            var baseRt = Place(name, root.transform, anchor, pos, size, ring, true);
            var knobRt = Place(name + "_k", baseRt, new Vector2(.5f, .5f), Vector2.zero, size * .42f, disc, true);
            var go = knobRt.gameObject; go.SetActive(false);                     // define controlPath antes do OnEnable
            var s = go.AddComponent<OnScreenStick>(); s.controlPath = path; s.movementRange = size * .4f;
            go.SetActive(true);
            onScreen.Add(s); items.Add(baseRt); AddDrag(baseRt, name);
        }

        void Button(string name, string label, string path, Vector2 anchor, Vector2 pos, float size)
        {
            var rt = Place(name, root.transform, anchor, pos, size, disc, true);
            var go = rt.gameObject; go.SetActive(false);
            var b = go.AddComponent<OnScreenButton>(); b.controlPath = path;
            go.SetActive(true);
            var tx = new GameObject("t", typeof(RectTransform), typeof(Text)); tx.transform.SetParent(rt, false);
            var trt = (RectTransform)tx.transform; trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one; trt.offsetMin = trt.offsetMax = Vector2.zero;
            var t = tx.GetComponent<Text>(); t.font = font; t.text = label; t.alignment = TextAnchor.MiddleCenter;
            t.fontSize = (int)(size * .26f); t.color = new Color(.85f, .81f, .72f); t.raycastTarget = false;
            onScreen.Add(b); items.Add(rt); AddDrag(rt, name);
        }

        void SmallBtn(string label, Vector2 pos, Action act)
        {
            var rt = Place("sm_" + label, root.transform, new Vector2(1, 1), pos, 90f, disc, true);
            var b = rt.gameObject.AddComponent<UnityEngine.UI.Button>(); b.onClick.AddListener(() => act());
            var tx = new GameObject("t", typeof(RectTransform), typeof(Text)); tx.transform.SetParent(rt, false);
            var trt = (RectTransform)tx.transform; trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one; trt.offsetMin = trt.offsetMax = Vector2.zero;
            var t = tx.GetComponent<Text>(); t.font = font; t.text = label; t.alignment = TextAnchor.MiddleCenter; t.fontSize = 24; t.color = new Color(.85f, .81f, .72f); t.raycastTarget = false;
            items.Add(rt);
        }

        public void Build(Transform canvas, Font f, Action onPause, Action onInv)
        {
            font = f; ring = MakeSprite(false); disc = MakeSprite(true);
            root = new GameObject("TouchControls", typeof(RectTransform));
            var r = (RectTransform)root.transform; r.SetParent(canvas, false);
            r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one; r.offsetMin = r.offsetMax = Vector2.zero;

            var BL = new Vector2(0, 0); var BR = new Vector2(1, 0);
            Stick("move", "<Gamepad>/leftStick", BL, new Vector2(250, 250), 260);
            Stick("look", "<Gamepad>/rightStick", BR, new Vector2(-400, 360), 220);
            Button("attack", "Golpear", "<Gamepad>/buttonWest", BR, new Vector2(-140, 160), 170);
            Button("jump", "Pular", "<Gamepad>/buttonSouth", BR, new Vector2(-330, 110), 110);
            Button("dodge", "Rolar", "<Gamepad>/buttonEast", BR, new Vector2(-140, 360), 110);
            Button("block", "Guarda", "<Gamepad>/leftShoulder", BR, new Vector2(-520, 150), 110);
            Button("run", "Correr", "<Gamepad>/rightShoulder", BL, new Vector2(470, 120), 100);
            Button("use", "Usar", "<Gamepad>/buttonNorth", BR, new Vector2(-140, 520), 110);
            SmallBtn("II", new Vector2(-70, -70), onPause);
            SmallBtn("Bolsa", new Vector2(-180, -70), onInv);
            SetScale(SettingsManager.I.TouchScale);
        }

        public void SetScale(float s) { foreach (var i in items) i.localScale = Vector3.one * s; }
        public void SetVisible(bool v) { if (root && root.activeSelf != v) root.SetActive(v); }

        /// <summary>Modo de edição: desliga os controles virtuais e permite arrastar cada um.</summary>
        public void SetEdit(bool on)
        {
            foreach (var b in onScreen) b.enabled = !on;
            foreach (var d in drags) d.enabled = on;
        }
    }
}
