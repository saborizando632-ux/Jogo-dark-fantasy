using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Valmora
{
    /// <summary>
    /// Todas as ações usam o Input System. Touch: OnScreenStick/OnScreenButton escrevem num Gamepad virtual.
    /// Teclado e mouse: bindings diretos. O modo alterna automaticamente (sem reiniciar a partida).
    /// </summary>
    public class InputRouter : MonoBehaviour
    {
        public static InputRouter I;
        public InputActionMap Map;
        public InputAction Move, LookMouse, LookStick, Jump, Sprint, Dodge, Attack, Block, Interact, Inventory, Pause, Flask;
        public bool KbmMode { get; private set; }
        public static event Action<bool> ModeChanged;

        public struct Rebindable { public string label; public InputAction action; public int index; }
        public Rebindable[] Rebindables;

        InputAction Btn(string n, params string[] paths)
        {
            var a = Map.AddAction(n, InputActionType.Button);
            foreach (var p in paths) a.AddBinding(p);
            return a;
        }

        void Awake()
        {
            I = this;
            Map = new InputActionMap("Player");

            Move = Map.AddAction("Move", InputActionType.Value);
            Move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/w").With("Down", "<Keyboard>/s")
                .With("Left", "<Keyboard>/a").With("Right", "<Keyboard>/d");   // índices 1..4
            Move.AddBinding("<Gamepad>/leftStick");

            LookMouse = Map.AddAction("LookMouse", InputActionType.Value, "<Mouse>/delta");
            LookStick = Map.AddAction("LookStick", InputActionType.Value, "<Gamepad>/rightStick");

            Jump = Btn("Jump", "<Keyboard>/space", "<Gamepad>/buttonSouth");
            Sprint = Btn("Sprint", "<Keyboard>/leftShift", "<Gamepad>/rightShoulder");
            Dodge = Btn("Dodge", "<Keyboard>/leftCtrl", "<Gamepad>/buttonEast");
            Attack = Btn("Attack", "<Mouse>/leftButton", "<Gamepad>/buttonWest");
            Block = Btn("Block", "<Mouse>/rightButton", "<Gamepad>/leftShoulder");
            Interact = Btn("Interact", "<Keyboard>/e", "<Gamepad>/buttonNorth");
            Inventory = Btn("Inventory", "<Keyboard>/i");
            Pause = Btn("Pause", "<Keyboard>/escape");
            Flask = Btn("Flask", "<Keyboard>/q");

            Rebindables = new[]
            {
                new Rebindable{label="Frente",   action=Move,      index=1},
                new Rebindable{label="Trás",     action=Move,      index=2},
                new Rebindable{label="Esquerda", action=Move,      index=3},
                new Rebindable{label="Direita",  action=Move,      index=4},
                new Rebindable{label="Pular",    action=Jump,      index=0},
                new Rebindable{label="Correr",   action=Sprint,    index=0},
                new Rebindable{label="Esquivar", action=Dodge,     index=0},
                new Rebindable{label="Interagir",action=Interact,  index=0},
                new Rebindable{label="Inventário",action=Inventory,index=0},
                new Rebindable{label="Frasco",   action=Flask,     index=0},
            };

            string json = PlayerPrefs.GetString("binds", "");
            if (!string.IsNullOrEmpty(json)) Map.LoadBindingOverridesFromJson(json);
            Map.Enable();

            KbmMode = !Application.isMobilePlatform;   // no editor/PC começa em teclado+mouse
        }

        void OnDestroy() { Map?.Disable(); Map?.Dispose(); }

        void SetMode(bool kbm)
        {
            if (kbm == KbmMode) return;
            KbmMode = kbm;
            ModeChanged?.Invoke(kbm);
        }

        void Update()
        {
            var kb = Keyboard.current; var ms = Mouse.current; var ts = Touchscreen.current;
            bool hasKbm = kb != null && ms != null;

            bool kbmActivity = hasKbm &&
                (kb.anyKey.wasPressedThisFrame || ms.delta.ReadValue().sqrMagnitude > 0.25f || ms.leftButton.wasPressedThisFrame);
            bool touchActivity = ts != null && ts.primaryTouch.press.wasPressedThisFrame &&
                !(ms != null && ms.leftButton.wasPressedThisFrame);

            if (kbmActivity && !touchActivity) SetMode(true);          // detectou teclado/mouse -> esconde controles virtuais
            else if (touchActivity) SetMode(false);                    // toque na tela -> mostra controles virtuais
            if (!hasKbm && KbmMode && Application.isMobilePlatform) SetMode(false);   // desconectado -> volta ao touch

            bool lockCursor = KbmMode && Game.Playing;
            Cursor.lockState = lockCursor ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !lockCursor;
        }

        /// <summary>Delta de câmera em graus (mouse em pixels * 0,1; analógico em graus/s).</summary>
        public Vector2 ReadLook(float dt)
        {
            Vector2 v = LookStick.ReadValue<Vector2>() * 160f * dt;
            if (KbmMode) v += LookMouse.ReadValue<Vector2>() * 0.1f;
            return v;
        }

        public void Rebind(InputAction a, int idx, Action done)
        {
            Map.Disable();
            a.PerformInteractiveRebinding(idx)
                .WithControlsExcluding("<Mouse>")
                .WithControlsExcluding("<Pointer>/position")
                .WithControlsExcluding("<Touchscreen>")
                .WithCancelingThrough("<Keyboard>/escape")
                .OnComplete(op => { op.Dispose(); Map.Enable(); SaveBinds(); done?.Invoke(); })
                .OnCancel(op => { op.Dispose(); Map.Enable(); done?.Invoke(); })
                .Start();
        }

        public void SaveBinds()
        {
            PlayerPrefs.SetString("binds", Map.SaveBindingOverridesAsJson());
            PlayerPrefs.Save();
        }
    }
}
