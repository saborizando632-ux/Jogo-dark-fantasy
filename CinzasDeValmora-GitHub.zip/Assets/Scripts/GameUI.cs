using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Valmora
{
    public class GameUI : MonoBehaviour
    {
        static readonly Color Gold = new Color(.72f, .57f, .23f), Ink = new Color(.06f, .05f, .08f, .95f), Bone = new Color(.85f, .81f, .72f);
        static readonly Vector2 C = new Vector2(.5f, .5f);

        Font font; Transform root;
        RectTransform hpF, stF, bossF; Text prompt, toast, info, bossName, invTxt; Image flash;
        GameObject hud, bossBar, pMenu, pPause, pInv, pSet; TouchControls touch;
        float toastT, flashA; bool setOpen, editing;
        readonly List<Action> refresh = new List<Action>();

        // ---------- helpers de UI ----------
        RectTransform Box(Transform p, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            var r = new GameObject("b", typeof(RectTransform)).GetComponent<RectTransform>();
            r.SetParent(p, false); r.anchorMin = r.anchorMax = r.pivot = anchor; r.anchoredPosition = pos; r.sizeDelta = size; return r;
        }
        RectTransform Stretch(Transform p)
        {
            var r = new GameObject("s", typeof(RectTransform)).GetComponent<RectTransform>();
            r.SetParent(p, false); r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one; r.offsetMin = r.offsetMax = Vector2.zero; return r;
        }
        Image Fill(RectTransform r, Color c) { var i = r.gameObject.AddComponent<Image>(); i.color = c; return i; }
        Text Label(Transform p, string s, int sz, TextAnchor al, Vector2 pos, Vector2 size)
        {
            var r = Box(p, C, pos, size); var t = r.gameObject.AddComponent<Text>();
            t.font = font; t.text = s; t.fontSize = sz; t.alignment = al; t.color = Bone; t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap; return t;
        }
        Button Btn(Transform p, string s, Vector2 pos, Vector2 size, Action act, int sz = 34)
        {
            var r = Box(p, C, pos, size); var im = Fill(r, Ink);
            var o = r.gameObject.AddComponent<Outline>(); o.effectColor = Gold; o.effectDistance = new Vector2(2, 2);
            var b = r.gameObject.AddComponent<Button>(); b.targetGraphic = im; b.onClick.AddListener(() => act());
            var t = Stretch(r).gameObject.AddComponent<Text>();
            t.font = font; t.text = s; t.fontSize = sz; t.alignment = TextAnchor.MiddleCenter; t.color = Bone; t.raycastTarget = false;
            return b;
        }
        GameObject Panel(string n)
        {
            var r = Stretch(root); r.name = n; Fill(r, new Color(.03f, .03f, .05f, .9f)); return r.gameObject;
        }
        RectTransform Bar(Transform p, Vector2 pos, Vector2 size, Color c)
        {
            var bg = Box(p, new Vector2(0, 1), pos, size); Fill(bg, new Color(0, 0, 0, .6f));
            var o = bg.gameObject.AddComponent<Outline>(); o.effectColor = Gold; o.effectDistance = new Vector2(2, 2);
            var f = Stretch(bg); f.pivot = new Vector2(0, .5f); Fill(f, c); return f;
        }

        // ---------- construção ----------
        void Awake()
        {
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            var es = new GameObject("EventSystem", typeof(EventSystem)); es.transform.SetParent(transform);
            es.AddComponent<InputSystemUIInputModule>().AssignDefaultActions();

            var cg = new GameObject("UI", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            cg.transform.SetParent(transform);
            cg.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var cs = cg.GetComponent<CanvasScaler>();
            cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize; cs.referenceResolution = new Vector2(1920, 1080); cs.matchWidthOrHeight = .5f;
            root = cg.transform;

            BuildHud(); touch = gameObject.AddComponent<TouchControls>();
            touch.Build(root, font, () => { if (Game.State == GState.Play) Game.State = GState.Pause; }, () => { if (Game.State == GState.Play) Game.State = GState.Inventory; });
            BuildMenus(); BuildSettings();

            Game.ToastEvent += s => { toast.text = s; toastT = 2.6f; };
            Game.PlayerHurt += () => flashA = .6f;
        }

        void BuildHud()
        {
            hud = Stretch(root).gameObject; hud.name = "HUD";
            hpF = Bar(hud.transform, new Vector2(40, -40), new Vector2(460, 28), new Color(.64f, .18f, .18f));
            stF = Bar(hud.transform, new Vector2(40, -78), new Vector2(460, 18), new Color(.49f, .61f, .37f));
            var fl = Stretch(hud.transform); flash = Fill(fl, new Color(.64f, .1f, .1f, 0)); flash.raycastTarget = false;
            info = Label(hud.transform, "", 30, TextAnchor.UpperRight, new Vector2(660, 480), new Vector2(560, 60)); // reposicionado abaixo
            ((RectTransform)info.transform).anchorMin = ((RectTransform)info.transform).anchorMax = new Vector2(1, 1);
            ((RectTransform)info.transform).pivot = new Vector2(1, 1); ((RectTransform)info.transform).anchoredPosition = new Vector2(-300, -30);
            prompt = Label(hud.transform, "", 34, TextAnchor.MiddleCenter, new Vector2(0, -250), new Vector2(900, 60));
            toast = Label(hud.transform, "", 46, TextAnchor.MiddleCenter, new Vector2(0, 280), new Vector2(1400, 90));
            bossBar = new GameObject("Boss", typeof(RectTransform)); bossBar.transform.SetParent(hud.transform, false);
            var br = (RectTransform)bossBar.transform; br.anchorMin = br.anchorMax = new Vector2(.5f, 1); br.anchoredPosition = new Vector2(0, -50); br.sizeDelta = new Vector2(800, 60);
            bossName = Label(bossBar.transform, "Guardião de Cinzas", 32, TextAnchor.MiddleCenter, new Vector2(0, 14), new Vector2(800, 40));
            var bg = Box(bossBar.transform, C, new Vector2(0, -16), new Vector2(800, 22)); Fill(bg, new Color(0, 0, 0, .65f));
            var o = bg.gameObject.AddComponent<Outline>(); o.effectColor = Gold; o.effectDistance = new Vector2(2, 2);
            bossF = Stretch(bg); bossF.pivot = new Vector2(0, .5f); Fill(bossF, new Color(.48f, .12f, .29f));
        }

        void BuildMenus()
        {
            pMenu = Panel("Menu");
            Label(pMenu.transform, "CINZAS DE VALMORA", 120, TextAnchor.MiddleCenter, new Vector2(0, 260), new Vector2(1600, 160));
            Label(pMenu.transform, "A névoa engoliu o reino. Atravesse a floresta morta e enfrente o Guardião.", 34, TextAnchor.MiddleCenter, new Vector2(0, 150), new Vector2(1300, 60));
            Btn(pMenu.transform, "Iniciar jornada", new Vector2(0, 20), new Vector2(560, 100), () => Game.State = GState.Play);
            Btn(pMenu.transform, "Configurações", new Vector2(0, -100), new Vector2(560, 100), () => OpenSettings(pMenu));

            pPause = Panel("Pause");
            Label(pPause.transform, "PAUSADO", 90, TextAnchor.MiddleCenter, new Vector2(0, 220), new Vector2(1000, 120));
            Btn(pPause.transform, "Continuar", new Vector2(0, 80), new Vector2(560, 100), () => Game.State = GState.Play);
            Btn(pPause.transform, "Configurações", new Vector2(0, -40), new Vector2(560, 100), () => OpenSettings(pPause));
            Btn(pPause.transform, "Menu inicial", new Vector2(0, -160), new Vector2(560, 100), () => SceneManager.LoadScene(0));

            pInv = Panel("Inventario");
            Label(pInv.transform, "INVENTÁRIO", 90, TextAnchor.MiddleCenter, new Vector2(0, 340), new Vector2(1000, 120));
            invTxt = Label(pInv.transform, "", 38, TextAnchor.MiddleCenter, new Vector2(0, 200), new Vector2(1200, 160));
            Btn(pInv.transform, "Usar frasco (+50 vida)", new Vector2(0, 70), new Vector2(620, 90), () => { if (Game.Player) Game.Player.UseFlask(); });
            Btn(pInv.transform, "Equipar espada de ferro", new Vector2(0, -40), new Vector2(620, 90), () => { if (Game.Player) Game.Player.SetWeapon(0); });
            Btn(pInv.transform, "Equipar Lâmina do Guardião", new Vector2(0, -150), new Vector2(620, 90), () => { if (Game.Player) Game.Player.SetWeapon(1); });
            Btn(pInv.transform, "Fechar", new Vector2(0, -280), new Vector2(620, 90), () => Game.State = GState.Play);
        }

        void BuildSettings()
        {
            pSet = Panel("Settings");
            var S = SettingsManager.I; var I = InputRouter.I;
            Label(pSet.transform, "CONFIGURAÇÕES", 70, TextAnchor.MiddleCenter, new Vector2(0, 460), new Vector2(1000, 90));

            Action<string, float, Func<string>, Action, Action> row = (lab, y, val, minus, plus) =>
            {
                Label(pSet.transform, lab, 32, TextAnchor.MiddleLeft, new Vector2(-640, y), new Vector2(420, 60));
                Btn(pSet.transform, "-", new Vector2(-380, y), new Vector2(70, 70), () => { minus(); S.Save(); S.Apply(); RefreshAll(); });
                var v = Label(pSet.transform, "", 30, TextAnchor.MiddleCenter, new Vector2(-250, y), new Vector2(200, 60));
                Btn(pSet.transform, "+", new Vector2(-120, y), new Vector2(70, 70), () => { plus(); S.Save(); S.Apply(); RefreshAll(); });
                refresh.Add(() => v.text = val());
            };
            row("Gráficos", 330, () => SettingsManager.QNames[S.Quality], () => S.Quality = Mathf.Max(0, S.Quality - 1), () => S.Quality = Mathf.Min(4, S.Quality + 1));
            row("Sensibilidade", 230, () => S.Sens.ToString("0.0"), () => S.Sens = Mathf.Max(.3f, S.Sens - .1f), () => S.Sens = Mathf.Min(3f, S.Sens + .1f));
            row("Tamanho dos botões", 130, () => S.TouchScale.ToString("0.0"), () => { S.TouchScale = Mathf.Max(.6f, S.TouchScale - .1f); touch.SetScale(S.TouchScale); }, () => { S.TouchScale = Mathf.Min(1.6f, S.TouchScale + .1f); touch.SetScale(S.TouchScale); });
            Label(pSet.transform, "Mover botões (toque)", 32, TextAnchor.MiddleLeft, new Vector2(-640, 30), new Vector2(420, 60));
            var eb = Btn(pSet.transform, "Editar", new Vector2(-250, 30), new Vector2(260, 70), () => { editing = !editing; touch.SetEdit(editing); RefreshAll(); }, 30);
            refresh.Add(() => eb.GetComponentInChildren<Text>().text = editing ? "Concluir" : "Editar");

            Label(pSet.transform, "Teclas (mouse: esquerdo ataca, direito bloqueia)", 28, TextAnchor.MiddleCenter, new Vector2(330, 400), new Vector2(900, 50));
            float y0 = 330;
            foreach (var rb in I.Rebindables)
            {
                var r = rb;
                Label(pSet.transform, r.label, 32, TextAnchor.MiddleLeft, new Vector2(170, y0), new Vector2(300, 60));
                var b = Btn(pSet.transform, "", new Vector2(470, y0), new Vector2(260, 62), () =>
                {
                    I.Rebind(r.action, r.index, RefreshAll);
                }, 28);
                var t = b.GetComponentInChildren<Text>();
                refresh.Add(() => t.text = r.action.GetBindingDisplayString(r.index));
                y0 -= 68;
            }
            Btn(pSet.transform, "Voltar", new Vector2(0, -440), new Vector2(400, 90), () => { editing = false; touch.SetEdit(false); pSet.SetActive(false); setOpen = false; });
            pSet.SetActive(false); RefreshAll();
        }

        GameObject setFrom;
        void OpenSettings(GameObject from) { setFrom = from; setOpen = true; pSet.SetActive(true); RefreshAll(); }
        void RefreshAll() { foreach (var a in refresh) a(); }

        // ---------- loop ----------
        void Update()
        {
            var I = InputRouter.I; if (I == null) return;

            if (!setOpen)
            {
                if (I.Pause.WasPressedThisFrame())
                {
                    if (Game.State == GState.Play) Game.State = GState.Pause;
                    else if (Game.State == GState.Pause || Game.State == GState.Inventory) Game.State = GState.Play;
                }
                else if (I.Inventory.WasPressedThisFrame())
                {
                    if (Game.State == GState.Play) Game.State = GState.Inventory;
                    else if (Game.State == GState.Inventory) Game.State = GState.Play;
                }
            }

            pMenu.SetActive(Game.State == GState.Menu && !setOpen);
            pPause.SetActive(Game.State == GState.Pause && !setOpen);
            pInv.SetActive(Game.State == GState.Inventory && !setOpen);
            hud.SetActive(Game.State != GState.Menu);
            touch.SetVisible(!I.KbmMode && (Game.State == GState.Play || editing));   // KBM => controles virtuais ocultos

            var p = Game.Player;
            if (p != null)
            {
                hpF.localScale = new Vector3(Mathf.Clamp01(p.hp / p.maxHp), 1, 1);
                stF.localScale = new Vector3(Mathf.Clamp01(p.st / p.maxSt), 1, 1);
                string wn = Game.Weapon == 1 ? "Lâmina do Guardião" : "Espada de ferro";
                info.text = wn + "  ·  Frascos: " + Game.Flasks;
                prompt.text = (Game.Playing && p.Nearest != null)
                    ? (I.KbmMode ? I.Interact.GetBindingDisplayString(0) : "Usar") + ": " + p.Nearest.prompt : "";
                if (Game.State == GState.Inventory)
                    invTxt.text = "Vida " + Mathf.CeilToInt(p.hp) + "/" + (int)p.maxHp + "\nFrascos de cinzas: " + Game.Flasks + "\nArma: " + wn + " (dano " + (int)p.damage + ")" + (Game.HasBlade ? "" : "\n(Derrote o Guardião para obter a Lâmina)");
            }

            var boss = EnemyController.Boss;
            bossBar.SetActive(Game.BossActive && boss != null && !boss.IsDead);
            if (boss != null) bossF.localScale = new Vector3(boss.HpFraction, 1, 1);

            toastT -= Time.deltaTime;
            toast.color = new Color(Bone.r, Bone.g, Bone.b, Mathf.Clamp01(toastT));
            flashA = Mathf.MoveTowards(flashA, 0, Time.deltaTime * 2f);
            flash.color = new Color(.64f, .1f, .1f, flashA);
        }
    }
}
