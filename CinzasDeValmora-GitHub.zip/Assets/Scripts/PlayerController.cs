using UnityEngine;

namespace Valmora
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour, IDamageable
    {
        public float maxHp = 100f, maxSt = 100f, walkSpeed = 4.6f, runSpeed = 8f, camDist = 6.5f, damage = 22f;
        [HideInInspector] public float hp, st;
        public Interactable Nearest { get; private set; }

        CharacterController cc; Animator anim; Transform camT; Light glow;
        float yaw, pitch = 22f, vy, dodgeT, atkT, hurtT, regen, stepT;
        Vector3 dodgeDir, spawn; bool atkHit, blocking, dead;

        void Awake()
        {
            cc = GetComponent<CharacterController>();
            anim = GetComponentInChildren<Animator>();
            Game.Player = this;
            hp = maxHp; st = maxSt;
            spawn = transform.position;
            yaw = transform.eulerAngles.y;
        }

        void Start()
        {
            if (Camera.main) camT = Camera.main.transform;
            SetWeapon(Game.Weapon);
        }

        void Update()
        {
            var I = InputRouter.I;
            if (I == null || !Game.Playing || dead) { Nearest = null; return; }
            float dt = Time.deltaTime;

            // --- câmera ---
            Vector2 lk = I.ReadLook(dt) * SettingsManager.I.Sens;
            yaw += lk.x; pitch = Mathf.Clamp(pitch - lk.y, -20f, 70f);

            // --- entrada de movimento relativa à câmera ---
            Vector2 mv = I.Move.ReadValue<Vector2>();
            Vector3 dir = Quaternion.Euler(0, yaw, 0) * new Vector3(mv.x, 0, mv.y);
            if (dir.sqrMagnitude > 1f) dir.Normalize();

            atkT = Mathf.Max(0, atkT - dt); dodgeT = Mathf.Max(0, dodgeT - dt);
            hurtT = Mathf.Max(0, hurtT - dt); regen -= dt;

            blocking = I.Block.IsPressed() && atkT <= 0 && dodgeT <= 0 && st > 0;
            bool running = I.Sprint.IsPressed() && dir.sqrMagnitude > 0.04f && st > 0 && !blocking && atkT <= 0;

            if (I.Jump.WasPressedThisFrame() && cc.isGrounded && st >= 10f) { vy = 8f; st -= 10f; regen = 0.6f; }
            if (I.Dodge.WasPressedThisFrame() && dodgeT <= 0 && atkT <= 0 && st >= 25f)
            {
                dodgeT = 0.35f; st -= 25f; regen = 0.8f;
                dodgeDir = dir.sqrMagnitude > 0.01f ? dir.normalized : transform.forward;
                Sfx("swing");
            }
            if (I.Attack.WasPressedThisFrame() && atkT <= 0 && dodgeT <= 0 && st >= 12f)
            {
                atkT = 0.6f; atkHit = false; st -= 12f; regen = 0.8f;
                transform.rotation = Quaternion.Euler(0, yaw, 0);
                if (anim) anim.SetTrigger("Attack");
                Sfx("swing");
            }
            if (atkT > 0 && !atkHit && atkT < 0.35f) { atkHit = true; DoHit(); }
            if (I.Flask.WasPressedThisFrame()) UseFlask();

            // --- interativo mais próximo ---
            Nearest = null; float best = 999f;
            foreach (var it in Interactable.All)
            {
                float d = Vector3.Distance(it.transform.position, transform.position);
                if (d < it.range && d < best) { best = d; Nearest = it; }
            }
            if (I.Interact.WasPressedThisFrame() && Nearest != null) Nearest.Use();

            // --- movimento ---
            float sp = running ? runSpeed : walkSpeed;
            if (blocking) sp *= 0.4f;
            if (atkT > 0) sp *= 0.3f;
            Vector3 vel = dodgeT > 0 ? dodgeDir * 14f : dir * sp;
            if (running) { st -= 14f * dt; regen = 0.5f; }

            if (cc.isGrounded && vy < 0) vy = -2f;
            vy -= 25f * dt;
            cc.Move((vel + Vector3.up * vy) * dt);

            float target = (atkT > 0 || blocking) ? yaw : (dir.sqrMagnitude > 0.01f ? Mathf.Atan2(dir.x, dir.z) * Mathf.Rad2Deg : transform.eulerAngles.y);
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, target, 0), 12f * dt);

            if (regen <= 0 && !running && !blocking) st = Mathf.Min(maxSt, st + 24f * dt);
            st = Mathf.Max(0, st);

            float spd = new Vector3(vel.x, 0, vel.z).magnitude;
            if (anim) { anim.SetFloat("Speed", spd, 0.1f, dt); anim.SetBool("Block", blocking); }

            if (spd > 0.5f && cc.isGrounded)
            {
                stepT -= dt;
                if (stepT <= 0) { stepT = running ? 0.28f : 0.45f; Sfx(Vector3.Distance(transform.position, new Vector3(0, 0, -80)) < 30f ? "stepStone" : "step"); }
            }
        }

        void LateUpdate()
        {
            if (camT == null) { if (Camera.main) camT = Camera.main.transform; else return; }
            Vector3 tgt = transform.position + Vector3.up * 1.7f;
            Quaternion r = Quaternion.Euler(pitch, yaw, 0);
            Vector3 want = tgt - r * Vector3.forward * camDist;
            if (Physics.Linecast(tgt, want, out RaycastHit h, ~(1 << 2), QueryTriggerInteraction.Ignore))
                want = h.point + h.normal * 0.25f;
            camT.position = want;
            camT.rotation = Quaternion.LookRotation(tgt - want);
        }

        void DoHit()
        {
            bool any = false;
            foreach (var e in EnemyController.All.ToArray())
            {
                if (e == null || e.IsDead) continue;
                Vector3 d = e.transform.position - transform.position; d.y = 0;
                if (d.magnitude <= 2.8f + e.BodyRadius && Vector3.Angle(transform.forward, d) < 110f)
                { e.Hurt(damage, transform.position); any = true; }
            }
            if (any) Sfx("hit");
        }

        public void Hurt(float dmg, Vector3 from)
        {
            if (dead || dodgeT > 0 || hurtT > 0) return;
            bool blk = false;
            if (blocking)
            {
                Vector3 d = from - transform.position; d.y = 0;
                if (Vector3.Angle(transform.forward, d) < 80f) { blk = true; dmg *= 0.2f; st -= 18f; if (st <= 0) blocking = false; Sfx("block"); }
            }
            hp -= dmg; hurtT = 0.4f;
            if (!blk) { if (anim) anim.SetTrigger("Hit"); Game.RaiseHurt(); Sfx("hit"); }
            if (hp <= 0) Die();
        }

        void Die()
        {
            dead = true; hp = 0;
            if (anim) anim.SetBool("Dead", true);
            Game.Toast("Você sucumbiu às cinzas…");
            Game.RaiseDied();
            Invoke(nameof(Respawn), 2.5f);
        }

        void Respawn()
        {
            cc.enabled = false; transform.position = spawn; cc.enabled = true;
            hp = maxHp; st = maxSt; vy = 0; dead = false;
            if (anim) anim.SetBool("Dead", false);
        }

        public void UseFlask()
        {
            if (Game.Flasks <= 0 || hp >= maxHp) return;
            Game.Flasks--; hp = Mathf.Min(maxHp, hp + 50f); Sfx("heal");
        }

        public void SetWeapon(int w)
        {
            if (w == 1 && !Game.HasBlade) w = 0;
            Game.Weapon = w; damage = w == 1 ? 48f : 22f;
            if (w == 1 && glow == null)
            {
                var g = new GameObject("BladeGlow"); g.transform.SetParent(transform, false);
                g.transform.localPosition = new Vector3(-0.6f, 1.3f, 0.3f);
                glow = g.AddComponent<Light>(); glow.type = LightType.Point; glow.color = new Color(0.65f, 0.35f, 1f); glow.range = 7f; glow.intensity = 2.5f;
            }
            if (glow) glow.enabled = w == 1;
        }

        void Sfx(string n) { if (ProceduralAudio.I) ProceduralAudio.I.Play(n, transform.position); }
    }
}
