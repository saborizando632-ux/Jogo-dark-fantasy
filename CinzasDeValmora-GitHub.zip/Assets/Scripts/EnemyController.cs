using System.Collections.Generic;
using UnityEngine;

namespace Valmora
{
    [RequireComponent(typeof(CharacterController))]
    public class EnemyController : MonoBehaviour, IDamageable
    {
        public static readonly List<EnemyController> All = new List<EnemyController>();
        public static EnemyController Boss;

        public string title = "Inimigo";
        public float maxHp = 40, dmg = 8, speed = 3.5f, range = 2.2f, windup = 0.7f, cooldown = 1.4f, aggro = 28f, slamRadius = 10f;
        public bool isBoss;
        public GameObject bladePrefab;

        [HideInInspector] public float hp;
        public bool IsDead { get; private set; }
        public float BodyRadius => cc ? cc.radius : 0.8f;
        public float HpFraction => Mathf.Clamp01(hp / maxHp);
        public bool Awake_ => awake;

        CharacterController cc; Animator anim; LineRenderer tele;
        Vector3 home, lockDir; float vy, t, cd = 1.5f; int state, pattern; bool awake;

        void OnEnable() { All.Add(this); }
        void OnDisable() { All.Remove(this); }

        void Awake()
        {
            cc = GetComponent<CharacterController>();
            anim = GetComponentInChildren<Animator>();
            hp = maxHp; home = transform.position;
            if (isBoss)
            {
                Boss = this;
                Game.PlayerDied += ResetBoss;
                tele = new GameObject("Telegraph").AddComponent<LineRenderer>();
                tele.transform.SetParent(transform, false);
                tele.useWorldSpace = true; tele.loop = true; tele.positionCount = 48; tele.widthMultiplier = 0.4f;
                tele.material = new Material(Shader.Find("Sprites/Default"));
                tele.startColor = tele.endColor = new Color(1f, 0.15f, 0.1f, 0.9f);
                tele.enabled = false;
            }
        }

        void OnDestroy() { if (isBoss) Game.PlayerDied -= ResetBoss; }

        void Update()
        {
            if (!Game.Playing || IsDead || Game.Player == null) return;
            float dt = Time.deltaTime;
            Vector3 to = Game.Player.transform.position - transform.position; to.y = 0;
            float d = to.magnitude;

            if (isBoss && !awake)
            {
                if (d < aggro) { awake = true; Game.BossActive = true; Game.Toast(title); Sfx("roar"); }
                else { Gravity(dt); return; }
            }
            else if (d > aggro) { Gravity(dt); SetSpeed(0, dt); return; }

            cd -= dt;
            float moveSpd = 0;
            if (state == 1)
            {
                t -= dt;
                float pr = 1f - Mathf.Clamp01(t / windup);
                Vector3 fd = pattern == 1 ? lockDir : to.normalized;
                Face(fd, dt);
                if (isBoss && pattern == 0) UpdateTele(pr);
                if (pattern == 1 && pr > 0.5f) { Step(lockDir * speed * 5f, dt); moveSpd = speed * 5f; }
                else Gravity(dt);
                if (t <= 0) Strike();
            }
            else
            {
                Face(to.normalized, dt);
                if (d > range * 0.8f) { Step(to.normalized * speed, dt); moveSpd = speed; } else Gravity(dt);
                if (d < range + 0.5f && cd <= 0) Begin(to);
            }
            SetSpeed(moveSpd, dt);
        }

        void Begin(Vector3 to)
        {
            state = 1; t = windup;
            pattern = (isBoss && Random.value < 0.45f) ? 1 : 0;
            lockDir = to.normalized;
            if (anim) anim.SetTrigger("Attack");
            if (isBoss && pattern == 0) tele.enabled = true;
            if (isBoss) Sfx("roar");
        }

        void Strike()
        {
            if (Game.Player)
            {
                Vector3 to = Game.Player.transform.position - transform.position; to.y = 0;
                float reach = pattern == 0 ? (isBoss ? slamRadius : range + 0.8f) : range + 1.5f;
                if (to.magnitude <= reach) Game.Player.Hurt(dmg, transform.position);
            }
            if (tele) tele.enabled = false;
            state = 0; cd = cooldown;
            Sfx("swing");
        }

        void UpdateTele(float pr)
        {
            float r = slamRadius * pr;
            Vector3 c = transform.position + Vector3.up * 0.3f;
            for (int i = 0; i < 48; i++)
            {
                float a = i / 48f * Mathf.PI * 2f;
                tele.SetPosition(i, c + new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a)) * r);
            }
        }

        void Face(Vector3 dir, float dt)
        {
            if (dir.sqrMagnitude < 0.001f) return;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 6f * dt);
        }

        void Step(Vector3 v, float dt)
        {
            if (cc.isGrounded && vy < 0) vy = -2f;
            vy -= 25f * dt;
            cc.Move((v + Vector3.up * vy) * dt);
        }

        void Gravity(float dt) { Step(Vector3.zero, dt); }
        void SetSpeed(float s, float dt) { if (anim) anim.SetFloat("Speed", s, 0.1f, dt); }

        public void Hurt(float d, Vector3 from)
        {
            if (IsDead) return;
            hp -= d;
            if (!isBoss)
            {
                Vector3 k = transform.position - from; k.y = 0;
                if (cc.enabled) cc.Move(k.normalized * 1.2f);
                if (anim) anim.SetTrigger("Hit");
            }
            if (hp <= 0) Die();
        }

        void Die()
        {
            IsDead = true;
            if (anim) anim.SetBool("Dead", true);
            cc.enabled = false;
            if (tele) tele.enabled = false;
            if (isBoss)
            {
                Game.BossActive = false;
                Game.Toast("Guardião de Cinzas derrotado");
                if (bladePrefab) Instantiate(bladePrefab, transform.position + new Vector3(0, 1.2f, 0) + transform.forward * 4f, Quaternion.identity);
            }
            else if (Random.value < 0.4f) { Game.Flasks++; Game.Toast("+1 frasco de cinzas"); }
            Destroy(gameObject, 4f);
        }

        void ResetBoss()
        {
            if (!isBoss || IsDead || !awake) return;
            awake = false; hp = maxHp; state = 0; Game.BossActive = false;
            cc.enabled = false; transform.position = home; cc.enabled = true;
            if (tele) tele.enabled = false;
        }

        void Sfx(string n) { if (ProceduralAudio.I) ProceduralAudio.I.Play(n, transform.position); }
    }
}
