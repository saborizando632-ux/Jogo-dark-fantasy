using System;
using System.Collections.Generic;
using UnityEngine;

namespace Valmora
{
    public enum GState { Menu, Play, Pause, Inventory }

    public interface IDamageable { void Hurt(float dmg, Vector3 from); }

    public static class Game
    {
        public static GState State = GState.Menu;
        public static PlayerController Player;
        public static int Flasks = 1;
        public static int Weapon;               // 0 = espada de ferro, 1 = Lâmina do Guardião
        public static bool HasBlade, BossActive;
        public static event Action<string> ToastEvent;
        public static event Action PlayerDied, PlayerHurt;
        public static bool Playing => State == GState.Play;
        public static void Toast(string s) { ToastEvent?.Invoke(s); }
        public static void RaiseDied() { PlayerDied?.Invoke(); }
        public static void RaiseHurt() { PlayerHurt?.Invoke(); }
        public static void Reset()
        {
            State = GState.Menu; Flasks = 1; Weapon = 0; HasBlade = false; BossActive = false;
            Player = null; ToastEvent = null; PlayerDied = null; PlayerHurt = null;
        }
    }

    /// <summary>Único objeto "lógico" da cena. Cria entrada, áudio, configurações e interface.</summary>
    [DefaultExecutionOrder(-100)]
    public class Bootstrap : MonoBehaviour
    {
        void Awake()
        {
            Game.Reset();
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            gameObject.AddComponent<InputRouter>();
            gameObject.AddComponent<ProceduralAudio>();
            gameObject.AddComponent<SettingsManager>();
            gameObject.AddComponent<GameUI>();
        }
    }

    public abstract class Interactable : MonoBehaviour
    {
        public static readonly List<Interactable> All = new List<Interactable>();
        public string prompt = "Interagir";
        public float range = 3.5f;
        protected virtual void OnEnable() { All.Add(this); }
        protected virtual void OnDisable() { All.Remove(this); }
        public abstract void Use();
    }

    public class Chest : Interactable
    {
        public Light glow;
        bool open;
        public override void Use()
        {
            if (open) return;
            open = true;
            Game.Flasks += 2;
            Game.Toast("Baú aberto: +2 frascos de cinzas");
            if (ProceduralAudio.I) ProceduralAudio.I.Play("chest", transform.position);
            if (glow) glow.enabled = false;
            enabled = false;
        }
    }

    public class BladePickup : Interactable
    {
        float t;
        void Update()
        {
            t += Time.deltaTime;
            transform.Rotate(0, 60f * Time.deltaTime, 0, Space.World);
        }
        public override void Use()
        {
            Game.HasBlade = true;
            if (Game.Player) Game.Player.SetWeapon(1);
            Game.Toast("Lâmina do Guardião equipada");
            Destroy(gameObject);
        }
    }

    public class Flicker : MonoBehaviour
    {
        Light l; float baseI, seed;
        void Awake() { l = GetComponent<Light>(); baseI = l.intensity; seed = UnityEngine.Random.value * 50f; }
        void Update() { l.intensity = baseI * (0.8f + Mathf.PerlinNoise(Time.time * 7f, seed) * 0.45f); }
    }

    public class FollowTarget : MonoBehaviour
    {
        public Vector3 offset;
        void LateUpdate() { if (Game.Player) transform.position = Game.Player.transform.position + offset; }
    }
}
