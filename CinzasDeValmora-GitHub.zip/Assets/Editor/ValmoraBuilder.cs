using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Valmora.EditorTools
{
    public static class CI
    {
        public static void Prepare() { Builder.Prepare(false); }
        public static void BuildApk() { Builder.Build(false); }
        public static void BuildAab() { Builder.Build(true); }
    }

    public static class Builder
    {
        const string Scene = "Assets/Scenes/Main.unity";
        static readonly string[] Dirs = { "Assets/Scenes", "Assets/Prefabs", "Assets/Materials", "Assets/Animations", "Assets/Settings" };

        [MenuItem("Valmora/1 - Preparar projeto (gera tudo)")]
        public static void PrepareMenu() { Prepare(false); }
        [MenuItem("Valmora/2 - Regenerar cena e prefabs")]
        public static void Regenerate() { Prepare(true); }
        [MenuItem("Valmora/3 - Build APK")]
        public static void BuildApkMenu() { Build(false); }
        [MenuItem("Valmora/4 - Build AAB")]
        public static void BuildAabMenu() { Build(true); }

        // ===================================================================== PREPARO
        public static void Prepare(bool force)
        {
            foreach (var d in Dirs) Directory.CreateDirectory(d);
            AssetDatabase.Refresh();
            bool needRestart = AndroidSettings();
            SetupPipeline();

            if (!force && File.Exists(Scene))
            {
                Debug.Log("[Valmora] Cena já existe; use Valmora > 2 para regenerar.");
            }
            else
            {
                if (AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Models/ancient_guardian.glb") == null)
                {
                    Debug.LogError("[Valmora] Os .glb não foram importados. Confirme que o pacote com.unity.cloud.gltfast está instalado (Window > Package Manager) e rode de novo.");
                    return;
                }
                var vc = VertexMat();
                var ctrl = BuildController();
                var prefabs = BuildPrefabs(vc, ctrl);
                BuildScene(prefabs);
            }
            AssetDatabase.SaveAssets();
            if (needRestart && !Application.isBatchMode)
                EditorUtility.DisplayDialog("Valmora", "O Input System novo foi ativado. Reinicie o Unity Editor quando ele pedir.", "OK");
        }

        // ===================================================================== ANDROID
        static bool AndroidSettings()
        {
            PlayerSettings.companyName = "Valmora Studio";
            PlayerSettings.productName = "Cinzas de Valmora";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.valmora.cinzas");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.Vulkan, GraphicsDeviceType.OpenGLES3 });

            // Input System novo como único backend
            bool changed = false;
            var ps = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset").FirstOrDefault();
            if (ps != null)
            {
                var so = new SerializedObject(ps);
                var p = so.FindProperty("activeInputHandler");
                if (p != null && p.intValue != 1) { p.intValue = 1; so.ApplyModifiedProperties(); changed = true; }
            }
            // Assinatura (opcional): variáveis de ambiente
            var ks = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PATH");
            if (!string.IsNullOrEmpty(ks))
            {
                PlayerSettings.Android.useCustomKeystore = true;
                PlayerSettings.Android.keystoreName = ks;
                PlayerSettings.Android.keystorePass = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PASS");
                PlayerSettings.Android.keyaliasName = Environment.GetEnvironmentVariable("ANDROID_KEY_ALIAS");
                PlayerSettings.Android.keyaliasPass = Environment.GetEnvironmentVariable("ANDROID_KEY_PASS");
            }
            return changed;
        }

        public static void Build(bool aab)
        {
            Prepare(false);
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            EditorUserBuildSettings.buildAppBundle = aab;
            Directory.CreateDirectory("Builds/Android");
            var opts = new BuildPlayerOptions
            {
                scenes = new[] { Scene },
                locationPathName = "Builds/Android/CinzasDeValmora." + (aab ? "aab" : "apk"),
                target = BuildTarget.Android,
                options = BuildOptions.None
            };
            var r = BuildPipeline.BuildPlayer(opts);
            if (r.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
            {
                Debug.LogError("[Valmora] Build falhou: " + r.summary.result);
                if (Application.isBatchMode) EditorApplication.Exit(1);
            }
        }

        // ===================================================================== URP
        static void SetupPipeline()
        {
            const string rp = "Assets/Settings/ValmoraURP.asset", rd = "Assets/Settings/ValmoraRenderer.asset";
            var asset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(rp);
            if (asset == null)
            {
                var data = ScriptableObject.CreateInstance<UniversalRendererData>();
                AssetDatabase.CreateAsset(data, rd);
                asset = UniversalRenderPipelineAsset.Create(data);
                AssetDatabase.CreateAsset(asset, rp);
            }
            asset.supportsHDR = true;
            GraphicsSettings.defaultRenderPipeline = asset;
            QualitySettings.renderPipeline = asset;
            EditorUtility.SetDirty(asset);
        }

        // ===================================================================== MATERIAIS
        static Material Mat(string path, string shader, Action<Material> cfg)
        {
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null) { m = new Material(Shader.Find(shader)); AssetDatabase.CreateAsset(m, path); }
            cfg(m); EditorUtility.SetDirty(m); return m;
        }
        static Texture2D Tex(string n) { return AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Textures/" + n); }

        // Preserva as cores por vértice dos GLB (o shader de partículas do URP multiplica a cor do vértice).
        static Material VertexMat()
        {
            return Mat("Assets/Materials/VertexColorLit.mat", "Universal Render Pipeline/Particles/Lit", m =>
            { m.SetColor("_BaseColor", Color.white); m.SetFloat("_Smoothness", 0.15f); m.enableInstancing = true; });
        }
        static Material Lit(string name, Texture2D t, Color c, Vector2 tiling, float smooth)
        {
            return Mat("Assets/Materials/" + name + ".mat", "Universal Render Pipeline/Lit", m =>
            {
                m.SetColor("_BaseColor", c); m.SetFloat("_Smoothness", smooth);
                if (t != null) { m.SetTexture("_BaseMap", t); m.SetTextureScale("_BaseMap", tiling); }
            });
        }

        // ===================================================================== ANIMAÇÕES
        static AnimationCurve Cv(params float[] tv)
        {
            var c = new AnimationCurve();
            for (int i = 0; i < tv.Length; i += 2) c.AddKey(tv[i], tv[i + 1]);
            for (int i = 0; i < c.length; i++) c.SmoothTangents(i, 0);
            return c;
        }
        static AnimationClip Clip(string name, float len, bool loop, Dictionary<string, AnimationCurve> curves)
        {
            var c = new AnimationClip { name = name, frameRate = 30 };
            foreach (var kv in curves) c.SetCurve(kv.Key, typeof(Transform), "localEulerAnglesRaw.x", kv.Value);
            var s = AnimationUtility.GetAnimationClipSettings(c); s.loopTime = loop; AnimationUtility.SetAnimationClipSettings(c, s);
            AssetDatabase.CreateAsset(c, "Assets/Animations/" + name + ".anim");
            return c;
        }
        static Dictionary<string, AnimationCurve> Gait(float len, float legAmp, float armAmp)
        {
            float h = len / 4f;
            return new Dictionary<string, AnimationCurve>
            {
                {"LegA", Cv(0,0, h,legAmp, 2*h,0, 3*h,-legAmp, len,0)},
                {"LegB", Cv(0,0, h,-legAmp, 2*h,0, 3*h,legAmp, len,0)},
                {"ArmA", Cv(0,0, h,-armAmp, 2*h,0, 3*h,armAmp, len,0)},
                {"ArmB", Cv(0,0, h,armAmp, 2*h,0, 3*h,-armAmp, len,0)},
            };
        }

        static AnimatorController BuildController()
        {
            const string path = "Assets/Animations/Humanoid.controller";
            AssetDatabase.DeleteAsset(path);
            var idle = Clip("Idle", 2f, true, new Dictionary<string, AnimationCurve>
            { {"ArmA", Cv(0,0,1,4,2,0)}, {"ArmB", Cv(0,0,1,-4,2,0)}, {"Head", Cv(0,0,1,2,2,0)} });
            var walk = Clip("Walk", .9f, true, Gait(.9f, 28f, 22f));
            var run = Clip("Run", .55f, true, Gait(.55f, 45f, 38f));
            var atk = Clip("Attack", .6f, false, new Dictionary<string, AnimationCurve>
            { {"ArmB", Cv(0,0,.15f,-160,.3f,-10,.6f,0)}, {"ArmA", Cv(0,0,.15f,-40,.3f,0,.6f,0)}, {"", Cv(0,0,.15f,-8,.3f,10,.6f,0)} });
            var hit = Clip("Hit", .4f, false, new Dictionary<string, AnimationCurve>
            { {"Head", Cv(0,0,.1f,-25,.4f,0)}, {"", Cv(0,0,.1f,-10,.4f,0)} });
            var blk = Clip("Block", 1f, true, new Dictionary<string, AnimationCurve>
            { {"ArmA", Cv(0,-85,1,-85)}, {"ArmB", Cv(0,-20,1,-20)} });
            var dead = Clip("Death", 1.2f, false, new Dictionary<string, AnimationCurve>
            { {"", Cv(0,0,.9f,88,1.2f,88)}, {"ArmA", Cv(0,0,.5f,-60,1.2f,-60)}, {"ArmB", Cv(0,0,.5f,-60,1.2f,-60)} });

            var c = AnimatorController.CreateAnimatorControllerAtPath(path);
            c.AddParameter("Speed", AnimatorControllerParameterType.Float);
            c.AddParameter("Attack", AnimatorControllerParameterType.Trigger);
            c.AddParameter("Hit", AnimatorControllerParameterType.Trigger);
            c.AddParameter("Dead", AnimatorControllerParameterType.Bool);
            c.AddParameter("Block", AnimatorControllerParameterType.Bool);
            var sm = c.layers[0].stateMachine;
            var sI = sm.AddState("Idle"); sI.motion = idle; sm.defaultState = sI;
            var sW = sm.AddState("Walk"); sW.motion = walk;
            var sR = sm.AddState("Run"); sR.motion = run;
            var sA = sm.AddState("Attack"); sA.motion = atk;
            var sH = sm.AddState("Hit"); sH.motion = hit;
            var sB = sm.AddState("Block"); sB.motion = blk;
            var sD = sm.AddState("Death"); sD.motion = dead;

            Action<AnimatorState, AnimatorState, AnimatorConditionMode, float, string> tr = (a, b, mode, th, prm) =>
            { var t = a.AddTransition(b); t.hasExitTime = false; t.duration = .1f; t.AddCondition(mode, th, prm); };
            tr(sI, sW, AnimatorConditionMode.Greater, .2f, "Speed");
            tr(sW, sI, AnimatorConditionMode.Less, .2f, "Speed");
            tr(sW, sR, AnimatorConditionMode.Greater, 6f, "Speed");
            tr(sR, sW, AnimatorConditionMode.Less, 6f, "Speed");
            foreach (var s in new[] { sA, sH })
            { var t = s.AddTransition(sI); t.hasExitTime = true; t.exitTime = 1f; t.duration = .1f; }

            Action<AnimatorState, AnimatorControllerParameterType, string> any = (dst, ty, prm) =>
            {
                var t = sm.AddAnyStateTransition(dst); t.hasExitTime = false; t.duration = .05f; t.canTransitionToSelf = false;
                if (ty == AnimatorControllerParameterType.Trigger) t.AddCondition(AnimatorConditionMode.If, 0, prm);
                else t.AddCondition(AnimatorConditionMode.If, 0, prm);
            };
            any(sA, AnimatorControllerParameterType.Trigger, "Attack");
            any(sH, AnimatorControllerParameterType.Trigger, "Hit");
            any(sB, AnimatorControllerParameterType.Bool, "Block");
            any(sD, AnimatorControllerParameterType.Bool, "Dead");
            tr(sB, sI, AnimatorConditionMode.IfNot, 0, "Block");
            tr(sD, sI, AnimatorConditionMode.IfNot, 0, "Dead");
            EditorUtility.SetDirty(c);
            return c;
        }

        // ===================================================================== PREFABS A PARTIR DOS GLB
        class Prefabs { public GameObject guardian, brute, tree, arch, chest, blade; }

        static GameObject MakePrefab(string glb, string name, Dictionary<string, int[]> groups, Material vc, RuntimeAnimatorController ctrl, Action<GameObject> extra)
        {
            var src = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Models/" + glb);
            if (src == null) { Debug.LogError("[Valmora] Modelo não importado: " + glb); return null; }
            var inst = (GameObject)PrefabUtility.InstantiatePrefab(src);
            PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
            inst.name = name; inst.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity); inst.transform.localScale = Vector3.one;

            foreach (var r in inst.GetComponentsInChildren<Renderer>())
            { var mats = new Material[r.sharedMaterials.Length]; for (int i = 0; i < mats.Length; i++) mats[i] = vc; r.sharedMaterials = mats; }

            if (groups != null)
            {
                // Cada "part_N" é uma malha com pivô na origem: criamos pivôs nos ombros/quadris/pescoço para o Animator.
                var parts = inst.GetComponentsInChildren<Transform>().Where(t => t.name.StartsWith("part_")).ToDictionary(t => t.name, t => t);
                foreach (var g in groups)
                {
                    var ts = g.Value.Where(i => parts.ContainsKey("part_" + i)).Select(i => parts["part_" + i]).ToList();
                    if (ts.Count == 0) continue;
                    Bounds b = default; bool first = true;
                    foreach (var t in ts) foreach (var r in t.GetComponentsInChildren<Renderer>())
                    { if (first) { b = r.bounds; first = false; } else b.Encapsulate(r.bounds); }
                    var pv = new GameObject(g.Key).transform;
                    pv.SetParent(inst.transform, false);
                    pv.position = new Vector3(b.center.x, g.Key == "Head" ? b.min.y : b.max.y, b.center.z);
                    foreach (var t in ts) t.SetParent(pv, true);
                }
            }
            if (ctrl != null)
            {
                var an = inst.GetComponent<Animator>(); if (an == null) an = inst.AddComponent<Animator>();
                an.runtimeAnimatorController = ctrl; an.applyRootMotion = false;
            }
            extra?.Invoke(inst);
            var path = "Assets/Prefabs/" + name + ".prefab";
            var saved = PrefabUtility.SaveAsPrefabAsset(inst, path);
            UnityEngine.Object.DestroyImmediate(inst);
            return saved;
        }

        static Prefabs BuildPrefabs(Material vc, RuntimeAnimatorController ctrl)
        {
            var P = new Prefabs();
            P.guardian = MakePrefab("ancient_guardian.glb", "Guardian", new Dictionary<string, int[]> {
                {"Head", new[]{1,2}}, {"ArmA", new[]{4,5}}, {"ArmB", new[]{8,9,12,13,14}}, {"LegA", new[]{6,7}}, {"LegB", new[]{10,11}} }, vc, ctrl, null);
            P.brute = MakePrefab("root_brute.glb", "RootBrute", new Dictionary<string, int[]> {
                {"Head", new[]{3,4,5,14,15}}, {"ArmA", new[]{1,6,7}}, {"ArmB", new[]{2,10,11}}, {"LegA", new[]{8,9}}, {"LegB", new[]{12,13}} }, vc, ctrl, null);
            P.tree = MakePrefab("dead_tree.glb", "DeadTree", null, vc, null, g =>
            { var c = g.AddComponent<CapsuleCollider>(); c.center = new Vector3(0, 2, 0); c.radius = .45f; c.height = 4f; });
            P.arch = MakePrefab("ruined_arch.glb", "RuinedArch", null, vc, null, g =>
            {
                foreach (var x in new[] { -1f, 1f })
                { var b = g.AddComponent<BoxCollider>(); b.center = new Vector3(x, 1.2f, 0); b.size = new Vector3(.5f, 2.4f, .55f); }
            });
            P.chest = MakePrefab("ancient_chest.glb", "AncientChest", null, vc, null, g =>
            {
                var c = g.AddComponent<Chest>(); c.prompt = "abrir baú";
                var lg = new GameObject("Glow"); lg.transform.SetParent(g.transform, false); lg.transform.localPosition = new Vector3(0, 1f, 0);
                var l = lg.AddComponent<Light>(); l.type = LightType.Point; l.color = new Color(1f, .7f, .3f); l.range = 6; l.intensity = 1.5f;
                c.glow = l;
            });
            P.blade = MakePrefab("iron_sword.glb", "BladePickup", null, vc, null, g =>
            {
                var b = g.AddComponent<BladePickup>(); b.prompt = "pegar Lâmina do Guardião";
                var lg = new GameObject("Glow"); lg.transform.SetParent(g.transform, false); lg.transform.localPosition = new Vector3(0, 1f, 0);
                var l = lg.AddComponent<Light>(); l.type = LightType.Point; l.color = new Color(.65f, .35f, 1f); l.range = 10; l.intensity = 3f;
                g.transform.localScale = Vector3.one * 1.4f;
            });
            return P;
        }

        // ===================================================================== MUNDO
        static float H(float x, float z)
        {
            float h = Mathf.Sin(x * .03f) * 3f + Mathf.Cos(z * .025f) * 3f + Mathf.Sin((x + z) * .07f) * 1.2f;
            h += Mathf.Pow(Mathf.Max(0, Mathf.Sqrt(x * x + z * z) - 120f) / 30f, 2) * 6f;
            h -= Mathf.Max(0, 1f - Vector2.Distance(new Vector2(x, z), new Vector2(70, 30)) / 32f) * 9f;
            float k = Mathf.Clamp01(1.5f - Vector2.Distance(new Vector2(x, z), new Vector2(0, -80)) / 30f);
            return h * (1 - k) + .5f * k;
        }

        static void SkyTexture()
        {
            const string path = "Assets/Textures/night_sky.png";
            const int W = 2048, Hh = 1024;
            var px = new Color32[W * Hh];
            Vector3 m1 = new Vector3(-.45f, .5f, -.74f).normalized, m2 = new Vector3(.7f, .45f, .55f).normalized;
            for (int j = 0; j < Hh; j++)
            {
                float v = (j + .5f) / Hh, th = (1f - v) * Mathf.PI, y = Mathf.Cos(th), r = Mathf.Sin(th);
                for (int i = 0; i < W; i++)
                {
                    float u = (i + .5f) / W, lon = (.5f - u) * Mathf.PI * 2f;
                    var d = new Vector3(r * Mathf.Cos(lon), y, r * Mathf.Sin(lon));
                    Color c = y > 0 ? Color.Lerp(new Color(.03f, .05f, .10f), new Color(.005f, .01f, .035f), Mathf.Pow(y, .6f)) : new Color(.01f, .015f, .03f);
                    uint hsh = (uint)(i * 73856093 ^ j * 19349663); hsh ^= hsh >> 13; hsh *= 0x5bd1e995; hsh ^= hsh >> 15;
                    if (y > 0 && (hsh % 4000) < 5) c += Color.white * (.4f + (hsh % 7) * .1f);
                    float d1 = Vector3.Dot(d, m1), d2 = Vector3.Dot(d, m2);
                    if (d1 > Mathf.Cos(.11f)) c = new Color(.85f, .88f, .98f) * (.85f + .15f * Mathf.Sin(i * .31f) * Mathf.Cos(j * .27f));
                    else c += new Color(.25f, .3f, .5f) * Mathf.Exp((d1 - 1f) * 60f);
                    if (d2 > Mathf.Cos(.035f)) c = new Color(.95f, .55f, .4f);
                    else c += new Color(.35f, .15f, .1f) * Mathf.Exp((d2 - 1f) * 250f);
                    px[j * W + i] = c;
                }
            }
            var t = new Texture2D(W, Hh, TextureFormat.RGBA32, false); t.SetPixels32(px); t.Apply();
            File.WriteAllBytes(path, t.EncodeToPNG()); UnityEngine.Object.DestroyImmediate(t);
            AssetDatabase.ImportAsset(path);
            var ti = (TextureImporter)AssetImporter.GetAtPath(path);
            ti.mipmapEnabled = false; ti.wrapMode = TextureWrapMode.Clamp; ti.maxTextureSize = 2048; ti.SaveAndReimport();
        }

        static GameObject Inst(GameObject prefab, Vector3 pos, float yaw, float scale, Transform parent = null)
        {
            var g = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            if (parent) g.transform.SetParent(parent, false);
            g.transform.position = pos; g.transform.rotation = Quaternion.Euler(0, yaw, 0); g.transform.localScale = Vector3.one * scale;
            return g;
        }
        static Vector3 OnGround(float x, float z, float up = 0) { return new Vector3(x, H(x, z) + up, z); }

        static GameObject Character(string name, GameObject model, Vector3 pos, float scale, float modelHeight, float radius)
        {
            var root = new GameObject(name);
            root.transform.position = pos;
            var cc = root.AddComponent<CharacterController>();
            cc.height = modelHeight * scale; cc.radius = Mathf.Min(radius * scale, cc.height / 2f - .01f);
            cc.center = new Vector3(0, cc.height / 2f, 0); cc.stepOffset = .4f; cc.skinWidth = .05f;
            var m = (GameObject)PrefabUtility.InstantiatePrefab(model);
            m.name = "Model"; m.transform.SetParent(root.transform, false); m.transform.localScale = Vector3.one * scale;
            return root;
        }
        static void EyeLight(GameObject root, float scale, Color c, float intensity)
        {
            var g = new GameObject("EyeLight"); g.transform.SetParent(root.transform, false); g.transform.localPosition = new Vector3(0, 2.4f * scale, .4f * scale);
            var l = g.AddComponent<Light>(); l.type = LightType.Point; l.color = c; l.range = 6f * scale; l.intensity = intensity;
        }
        static void Block(Transform parent, Vector3 center, Vector3 size, Material m, PrimitiveType t = PrimitiveType.Cube)
        {
            var g = GameObject.CreatePrimitive(t); g.transform.SetParent(parent, false);
            g.transform.position = center; g.transform.localScale = size; g.GetComponent<Renderer>().sharedMaterial = m;
        }

        static void BuildScene(Prefabs P)
        {
            SkyTexture();
            var sc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var rnd = new System.Random(7);
            Func<double> R = () => rnd.NextDouble();
            Vector3 castle = new Vector3(0, 0, -80);

            // ---- céu, neblina, luz ambiente ----
            var sky = Mat("Assets/Materials/Sky.mat", "Skybox/Panoramic", m =>
            { m.SetTexture("_MainTex", Tex("night_sky.png")); m.SetFloat("_Exposure", 1.2f); });
            RenderSettings.skybox = sky;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.12f, .15f, .28f);
            RenderSettings.ambientEquatorColor = new Color(.08f, .09f, .14f);
            RenderSettings.ambientGroundColor = new Color(.04f, .03f, .05f);
            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = new Color(.05f, .07f, .12f); RenderSettings.fogDensity = .02f;

            var moon = new GameObject("MoonLight").AddComponent<Light>();
            moon.type = LightType.Directional; moon.color = new Color(.62f, .72f, 1f); moon.intensity = 1.1f; moon.shadows = LightShadows.Soft;
            moon.transform.rotation = Quaternion.LookRotation(-new Vector3(-.45f, .5f, -.74f).normalized);
            RenderSettings.sun = moon;

            // ---- terreno ----
            var layer = new TerrainLayer { diffuseTexture = Tex("ash_ground_albedo.png"), tileSize = new Vector2(8, 8) };
            AssetDatabase.CreateAsset(layer, "Assets/Scenes/AshLayer.terrainlayer");
            var td = new TerrainData { heightmapResolution = 257, size = new Vector3(400, 70, 400) };
            var hs = new float[257, 257];
            for (int zi = 0; zi < 257; zi++) for (int xi = 0; xi < 257; xi++)
                hs[zi, xi] = Mathf.Clamp01((H(-200f + xi / 256f * 400f, -200f + zi / 256f * 400f) + 10f) / 70f);
            td.SetHeights(0, 0, hs); td.terrainLayers = new[] { layer };
            AssetDatabase.CreateAsset(td, "Assets/Scenes/TerrainData.asset");
            var tgo = Terrain.CreateTerrainGameObject(td); tgo.name = "Terrain"; tgo.transform.position = new Vector3(-200, -10, -200);
            var tmat = Mat("Assets/Materials/TerrainLit.mat", "Universal Render Pipeline/Terrain/Lit", m => { });
            tgo.GetComponent<Terrain>().materialTemplate = tmat;

            // ---- lago ----
            var water = GameObject.CreatePrimitive(PrimitiveType.Plane); water.name = "Lake";
            water.transform.position = new Vector3(70, -3.4f, 30); water.transform.localScale = new Vector3(9, 1, 9);
            UnityEngine.Object.DestroyImmediate(water.GetComponent<Collider>());
            water.GetComponent<Renderer>().sharedMaterial = Mat("Assets/Materials/Water.mat", "Universal Render Pipeline/Lit", m =>
            { m.SetColor("_BaseColor", new Color(.03f, .08f, .16f)); m.SetFloat("_Smoothness", .95f); m.SetFloat("_Metallic", .3f); });

            // ---- floresta morta ----
            var forest = new GameObject("DeadForest").transform;
            int n = 0;
            while (n < 170)
            {
                float x = (float)(R() - .5) * 280f, z = (float)(R() - .5) * 280f;
                if (Vector2.Distance(new Vector2(x, z), new Vector2(castle.x, castle.z)) < 42f || Vector2.Distance(new Vector2(x, z), new Vector2(0, 40)) < 8f || H(x, z) < -1.5f) continue;
                Inst(P.tree, OnGround(x, z, -.3f), (float)R() * 360f, 1.8f + (float)R() * 1.8f, forest); n++;
            }

            // ---- castelo (pedra texturizada + arcos do pacote) ----
            var stone = Lit("Stone", Tex("stone_albedo.png"), Color.white, new Vector2(4, 2), .1f);
            var wood = Lit("Wood", Tex("dead_wood_albedo.png"), Color.white, new Vector2(1, 2), .05f);
            var iron = Lit("Iron", Tex("worn_iron_albedo.png"), Color.white, new Vector2(1, 1), .4f);
            var cs = new GameObject("Castle").transform;
            float by = .5f;
            Action<float, float, float, float, float> wall = (cx, cz, sx, sz, hh) => Block(cs, castle + new Vector3(cx, by + hh / 2f, cz), new Vector3(sx, hh, sz), stone);
            wall(-16, 26, 20, 3, 14); wall(16, 26, 20, 3, 14); wall(0, -26, 52, 3, 14); wall(-26, 0, 3, 52, 14); wall(26, 0, 3, 52, 14);
            Block(cs, castle + new Vector3(0, by + 12.5f, 26), new Vector3(14, 3, 3), stone);
            foreach (var c in new[] { new Vector2(-26, 26), new Vector2(26, 26), new Vector2(-26, -26), new Vector2(26, -26) })
                Block(cs, castle + new Vector3(c.x, by + 12, c.y), new Vector3(9, 12, 9), stone, PrimitiveType.Cylinder);
            Block(cs, castle + new Vector3(-6.5f, by + 5, 26), new Vector3(.8f, 10, 1.2f), iron);
            Block(cs, castle + new Vector3(6.5f, by + 5, 26), new Vector3(.8f, 10, 1.2f), iron);
            Block(cs, castle + new Vector3(-9, by + 4, 24), new Vector3(1.2f, 8, 1.2f), wood);
            Block(cs, castle + new Vector3(9, by + 4, 24), new Vector3(1.2f, 8, 1.2f), wood);
            for (int i = 0; i < 4; i++) Inst(P.arch, OnGround(0, 25 - i * 22f, 0), 0, 3.2f, cs);   // alameda de arcos até o portão
            Inst(P.arch, castle + new Vector3(0, by, 12), 0, 4.5f, cs); Inst(P.arch, castle + new Vector3(0, by, -8), 0, 4.5f, cs);
            for (int i = 0; i < 9; i++) { float a = i * .7f; Inst(P.arch, OnGround(-45 + Mathf.Cos(a) * 12, 25 + Mathf.Sin(a) * 12), a * 57f + 90f, 2.4f, cs); }
            foreach (var tp in new[] { new Vector3(-10, 4, 20), new Vector3(10, 4, 20), new Vector3(-20, 4, -6), new Vector3(20, 4, -6) })
            {
                var t = new GameObject("Torch"); t.transform.SetParent(cs, false); t.transform.position = castle + tp + Vector3.up * by;
                var l = t.AddComponent<Light>(); l.type = LightType.Point; l.color = new Color(1f, .55f, .2f); l.range = 24; l.intensity = 2.2f; t.AddComponent<Valmora.Flicker>();
                Block(cs, t.transform.position - Vector3.up * 2f, new Vector3(.3f, 4f, .3f), wood);
            }

            // ---- baús ----
            foreach (var p in new[] { new Vector2(-20, 30), new Vector2(40, -10), new Vector2(-60, -45), new Vector2(25, 60) })
                Inst(P.chest, OnGround(p.x, p.y, .02f), (float)R() * 360f, 1.2f);

            // ---- jogador ----
            var player = Character("Player", P.guardian, OnGround(0, 40, .2f), .7f, 2.83f, .6f);
            player.layer = 2; player.transform.rotation = Quaternion.Euler(0, 180, 0);
            player.AddComponent<PlayerController>();

            // ---- inimigos ----
            Action<GameObject, string, float, float, float, float, float, float> cfg = (go, title, hp, dmg, sp, rng, wu, cdn) =>
            { var e = go.AddComponent<EnemyController>(); e.title = title; e.maxHp = hp; e.dmg = dmg; e.speed = sp; e.range = rng; e.windup = wu; e.cooldown = cdn; };
            for (int i = 0; i < 6; i++)      // Sentinelas (guardião pequeno)
            { float a = (float)R() * 6.28f, d = 30 + (float)R() * 60; var g = Character("Sentinela", P.guardian, OnGround(Mathf.Cos(a) * d, Mathf.Sin(a) * d - 10, .2f), .75f, 2.83f, .6f); EyeLight(g, .75f, new Color(.4f, 1f, .85f), 2f); cfg(g, "Sentinela", 45, 9, 3.8f, 2.4f, .7f, 1.4f); }
            for (int i = 0; i < 5; i++)      // Brutos de raízes
            { var g = Character("BrutoDeRaizes", P.brute, OnGround(-70 + (float)R() * 140, -40 + (float)R() * 60, .2f), .85f, 3.6f, .7f); EyeLight(g, .85f, new Color(1f, .6f, .25f), 2f); cfg(g, "Bruto de Raízes", 90, 14, 2.6f, 3f, .9f, 1.8f); }
            foreach (var p in new[] { new Vector2(-50, -20), new Vector2(55, -45), new Vector2(10, -30) })   // Gigantes
            { var g = Character("GiganteDeRaizes", P.brute, OnGround(p.x, p.y, .2f), 2f, 3.6f, .7f); EyeLight(g, 2f, new Color(1f, .3f, .2f), 3f); var e = g.AddComponent<EnemyController>(); e.title = "Gigante de Raízes"; e.maxHp = 220; e.dmg = 26; e.speed = 2f; e.range = 5.5f; e.windup = 1.1f; e.cooldown = 2.4f; }
            var bossGo = Character("GuardiaoDeCinzas", P.guardian, OnGround(castle.x, castle.z - 4, .6f), 3.6f, 2.83f, .6f);
            EyeLight(bossGo, 3.6f, new Color(1f, .15f, .15f), 6f);
            var be = bossGo.AddComponent<EnemyController>();
            be.title = "Guardião de Cinzas"; be.isBoss = true; be.maxHp = 700; be.dmg = 34; be.speed = 3.2f; be.range = 9f; be.windup = 1.3f; be.cooldown = 2.2f; be.aggro = 34f; be.slamRadius = 12f; be.bladePrefab = P.blade;

            // ---- câmera + pós-processamento ----
            var cam = new GameObject("Main Camera"); cam.tag = "MainCamera";
            var cm = cam.AddComponent<Camera>(); cm.fieldOfView = 65; cm.nearClipPlane = .1f; cm.farClipPlane = 380; cm.clearFlags = CameraClearFlags.Skybox;
            cam.AddComponent<AudioListener>();
            cam.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing = true;
            cam.transform.position = player.transform.position + new Vector3(0, 3, 6);

            var prof = ScriptableObject.CreateInstance<VolumeProfile>();
            AssetDatabase.CreateAsset(prof, "Assets/Settings/ValmoraVolume.asset");
            Action<VolumeComponent> addSub = c => AssetDatabase.AddObjectToAsset(c, prof);
            var bloom = prof.Add<Bloom>(true); bloom.intensity.Override(1.0f); bloom.threshold.Override(.9f); bloom.scatter.Override(.7f); addSub(bloom);
            var vig = prof.Add<Vignette>(true); vig.intensity.Override(.38f); addSub(vig);
            var ca = prof.Add<ColorAdjustments>(true); ca.saturation.Override(-25f); ca.contrast.Override(12f); addSub(ca);
            var tm = prof.Add<Tonemapping>(true); tm.mode.Override(TonemappingMode.ACES); addSub(tm);
            EditorUtility.SetDirty(prof);
            var vgo = new GameObject("PostFX"); var vol = vgo.AddComponent<Volume>(); vol.isGlobal = true; vol.sharedProfile = prof;

            // ---- partículas ambientais (esporos / cinzas) ----
            var mgo = new GameObject("Motes"); var ps = mgo.AddComponent<ParticleSystem>();
            var pm = ps.main; pm.startLifetime = 8f; pm.startSize = .08f; pm.startSpeed = .2f; pm.maxParticles = 300; pm.simulationSpace = ParticleSystemSimulationSpace.World; pm.startColor = new Color(.68f, .9f, 1f, .7f);
            var em = ps.emission; em.rateOverTime = 40; var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(40, 12, 40);
            mgo.GetComponent<ParticleSystemRenderer>().sharedMaterial = Mat("Assets/Materials/Mote.mat", "Universal Render Pipeline/Particles/Unlit", m => { m.SetColor("_BaseColor", new Color(.7f, .9f, 1f, .8f)); });
            mgo.AddComponent<FollowTarget>().offset = new Vector3(0, 3, 0);

            // ---- bootstrap ----
            new GameObject("Bootstrap").AddComponent<Bootstrap>();

            Directory.CreateDirectory("Assets/Scenes");
            EditorSceneManager.SaveScene(sc, Scene);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(Scene, true) };
            Debug.Log("[Valmora] Cena gerada: " + Scene);
        }
    }
}
